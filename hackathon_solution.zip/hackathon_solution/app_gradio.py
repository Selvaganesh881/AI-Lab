# app_gradio.py
# Minimal Gradio interface exposing PDF RAG chat and entity extraction for quick demos.

import gradio as gr
from core.pdf_utils import extract_pdf_text_bytes
from core.rag_utils import build_rag_chain_from_text
from core.ocr_utils import ocr_image_bytes
from core.entity_pipeline import extract_entities_from_text_block, normalize_entity_values

# global state for demo simplicity (single-user)
qa_chain = None

def process_pdf(file):
    global qa_chain
    text = extract_pdf_text_bytes(file.read())
    qa_chain = build_rag_chain_from_text(text)
    return "✅ Processed"

def ask_pdf(question):
    global qa_chain
    if qa_chain is None:
        return "Please process a PDF first."
    res = qa_chain.invoke(question)
    return res.get("result","(no answer)")

def extract_entities_img(file):
    text = ocr_image_bytes(file.read())
    ent = extract_entities_from_text_block(text)
    ents = ent.get("entities", [])
    normalized = [normalize_entity_values(e) for e in ents]
    return {"entities": normalized, "count": len(normalized)}

with gr.Blocks() as demo:
    gr.Markdown("## Hackathon RAG Demo (Local)")
    with gr.Row():
        pdf_file = gr.File(label="Upload PDF", file_types=[".pdf"])
        proc = gr.Button("Process PDF")
        proc.click(process_pdf, inputs=pdf_file, outputs=gr.Textbox())

    q = gr.Textbox(label="Ask PDF")
    ans = gr.Textbox(label="Answer")
    q.submit(ask_pdf, inputs=q, outputs=ans)

    gr.Markdown("---")
    img = gr.File(label="Upload Image for Entity Extraction")
    ent_box = gr.JSON(label="Entities")
    img.submit(extract_entities_img, inputs=img, outputs=ent_box)

if __name__ == "__main__":
    demo.launch()
