# app_streamlit.py
# Streamlit UI integrating PDF RAG chat, Audio transcription & analysis, Entity extraction, TestCase generation.

from __future__ import annotations
import streamlit as st
from core.pdf_utils import extract_pdf_text_bytes
from core.rag_utils import build_rag_chain_from_text
from core.audio_pipeline import transcribe_whisper_bytes, redact_pii_simple, analyze_transcript_with_llm
from core.ocr_utils import ocr_image_bytes
from core.entity_pipeline import extract_entities_from_text_block, normalize_entity_values
from core.testcase_pipeline import generate_test_cases_from_story, verify_test_case_against_spec

st.set_page_config(page_title="Hackathon RAG Suite", layout="wide")
st.title("Hackathon RAG Suite — Local (Streamlit)")

# Use tabs for each feature so the UI is clear
tab1, tab2, tab3, tab4 = st.tabs(["PDF RAG", "Audio → Analysis", "Entity Extractor", "Test Case Gen"])

# ---------------- PDF RAG ----------------
with tab1:
    st.header("PDF RAG Chat")
    pdf_file = st.file_uploader("Upload PDF (<=25 pages)", type=["pdf"])
    if st.button("Process PDF") and pdf_file:
        with st.spinner("Extracting text and building index..."):
            text = extract_pdf_text_bytes(pdf_file.read())
            st.session_state["qa_chain"] = build_rag_chain_from_text(text)
            st.success("Indexed PDF locally.")
    if "qa_chain" in st.session_state:
        qa = st.session_state["qa_chain"]
        q = st.text_input("Ask question about PDF:")
        if q:
            with st.spinner("Querying model..."):
                res = qa.invoke(q)
                answer = res.get("result", "(no answer)")
                st.write("**Answer:**")
                st.write(answer)
                # show sources if present
                srcs = res.get("source_documents", [])
                if srcs:
                    with st.expander("Sources"):
                        for i, d in enumerate(srcs, start=1):
                            snippet = (d.page_content or "")[:400].replace("\n"," ")
                            st.markdown(f"**{i}.** {snippet}...")

# ---------------- Audio ----------------
with tab2:
    st.header("Audio → Transcript & Analysis")
    audio_file = st.file_uploader("Upload audio file (wav/mp3):", type=["wav","mp3","m4a","mp4"])
    if st.button("Transcribe & Analyze") and audio_file:
        with st.spinner("Transcribing audio..."):
            audio_bytes = audio_file.read()
            trans = transcribe_whisper_bytes(audio_bytes)
            transcript = trans.get("transcript","")
            transcript = redact_pii_simple(transcript)
            st.subheader("Transcript")
            st.write(transcript)
            with st.spinner("Analyzing transcript..."):
                analysis = analyze_transcript_with_llm(transcript)
                st.subheader("Analysis (JSON)")
                st.json(analysis)

# ---------------- Entity Extractor ----------------
with tab3:
    st.header("Entity Extraction (Image/PDF)")
    img_file = st.file_uploader("Upload image (png/jpg) for OCR & entity extraction:", type=["png","jpg","jpeg"])
    if st.button("Extract Entities") and img_file:
        with st.spinner("Running OCR..."):
            text = ocr_image_bytes(img_file.read())
            st.text_area("OCR Text", text, height=200)
            with st.spinner("Extracting entities via LLM..."):
                ent = extract_entities_from_text_block(text)
                # normalize entities
                ents = ent.get("entities", [])
                normalized = [normalize_entity_values(e) for e in ents]
                st.subheader("Entities (normalized)")
                st.json({"entities": normalized, "count": len(normalized)})

# ---------------- Test Case Generation ----------------
with tab4:
    st.header("Test Case Generation & Traceability")
    story_text = st.text_area("Paste a user story or spec text here:", height=200)
    if st.button("Generate Test Cases") and story_text.strip():
        with st.spinner("Generating test cases..."):
            gen = generate_test_cases_from_story(story_text)
            st.subheader("Generated Test Cases")
            st.json(gen)
            # run verification on first test case as demo
            tcs = gen.get("test_cases", []) if isinstance(gen, dict) else []
            if tcs:
                with st.spinner("Verifying first test case against spec..."):
                    verify = verify_test_case_against_spec(tcs[0], story_text)
                    st.subheader("Verification of first test case")
                    st.json(verify)
