# core/audio_pipeline.py
# Audio transcription (Whisper) + LLM analysis (summary/sentiment/agent KPIs)
# NOTE: Replace 'openai' usage with your Azure wrapper / REST calls if needed.

import io
import json
import re
from typing import Dict, Any
import openai   # placeholder - if you don't have this, replace with your SDK/REST
from .config import settings

def transcribe_whisper_bytes(audio_bytes: bytes, model: str | None = None) -> Dict[str, Any]:
    """Transcribe audio bytes using Whisper model.
    Returns a dict {'transcript': str, 'segments': list}.
    Note: the precise SDK call can vary; adapt to your environment.
    """
    if model is None:
        model = settings.WHISPER_MODEL
    # wrap bytes to file-like object for SDK
    audio_file = io.BytesIO(audio_bytes)
    # call transcription endpoint (SDK-specific)
    # Example uses "openai": openai.Audio.transcriptions.create(...)
    resp = openai.Audio.transcriptions.create(model=model, file=audio_file)
    # extract text and segments if available
    text = getattr(resp, "text", None) or resp.get("text", "")
    segments = resp.get("segments", []) if isinstance(resp, dict) else []
    return {"transcript": text, "segments": segments}

def redact_pii_simple(text: str) -> str:
    """Basic PII redaction: emails and 10-digit phone numbers.
    Good enough for demos; replace or expand for production.
    """
    # redact emails
    text = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}", "[REDACTED_EMAIL]", text)
    # redact phone numbers (simple)
    text = re.sub(r"\\b\\d{10}\\b", "[REDACTED_PHONE]", text)
    # collapse whitespace
    text = " ".join(text.split())
    return text

def analyze_transcript_with_llm(transcript: str, model: str | None = None) -> Dict[str, Any]:
    """Use Chat LLM to produce JSON with summary, sentiment, and agent KPIs.
    We instruct the model to return JSON only for programmatic parsing.
    """
    if model is None:
        model = settings.LLM_MODEL

    prompt = f"""Transcript:
{transcript}

Tasks (Return ONLY valid JSON):
1) summary: one paragraph <= 120 words.
2) sentiment: {{label: Positive|Neutral|Negative, confidence: 0-1, reason: short}}
3) agent_eval: {{greeting:1-5, empathy:1-5, policy_adherence:1-5, resolution:1-5, escalation_need:1-5, improvements:[str,str]}}

Output example:
{{
  "summary":"...",
  "sentiment":{{"label":"Negative","confidence":0.75,"reason":"..."}},
  "agent_eval":{{"greeting":4,"empathy":3,"policy_adherence":4,"resolution":2,"escalation_need":5,"improvements":["...","..."]}}
}}
"""

    # call chat completion
    resp = openai.ChatCompletion.create(model=model, messages=[{"role":"system","content":"Return valid JSON only."},{"role":"user","content":prompt}], temperature=0)
    raw = resp.choices[0].message["content"]
    try:
        parsed = json.loads(raw)
    except Exception as e:
        # if LLM doesn't return JSON, include raw for debugging
        parsed = {"error": "invalid_json", "raw": raw, "parse_error": str(e)}
    return parsed
