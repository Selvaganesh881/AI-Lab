# core/ocr_utils.py
# Tesseract OCR helpers (local Tesseract must be installed on machine).

import io
from PIL import Image
import pytesseract

def ocr_image_bytes(image_bytes: bytes, lang: str = "eng") -> str:
    """Run Tesseract OCR on raw image bytes and return extracted text.
    - loads image into PIL and calls pytesseract.image_to_string
    - lang param lets you specify Tesseract language packs
    """
    image = Image.open(io.BytesIO(image_bytes))   # create PIL image from bytes
    # run OCR; config can be extended for layout or char whitelist
    text = pytesseract.image_to_string(image, lang=lang)
    return text

def ocr_image_file(path: str, lang: str = "eng") -> str:
    """Run Tesseract on an image file path.
    """
    image = Image.open(path)
    return pytesseract.image_to_string(image, lang=lang)
