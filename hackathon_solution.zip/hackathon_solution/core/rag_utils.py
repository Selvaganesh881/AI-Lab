# core/rag_utils.py
# RAG pipeline: chunking -> embedding -> Chroma index -> Retriever -> RetrievalQA chain

from __future__ import annotations
import os
from typing import List
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain.chains import RetrievalQA
from .llm_utils import get_llm, get_embedding_model
from .config import settings
import hashlib

def _content_hash(text: str) -> str:
    """Short content hash used to persist index by document."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]

def build_rag_chain_from_text(text: str, persist_root: str | None = None) -> RetrievalQA:
    """Build or load a Chroma-based RAG chain from text.
    - chunks are created to preserve context across page breaks.
    - index stored under persist_root/<doc_hash>/ for caching.
    """
    if persist_root is None:
        persist_root = settings.PERSIST_ROOT
    os.makedirs(persist_root, exist_ok=True)

    # chunk the text into overlapping chunks
    splitter = RecursiveCharacterTextSplitter(chunk_size=settings.CHUNK_SIZE, chunk_overlap=settings.CHUNK_OVERLAP)
    chunks = splitter.split_text(text)

    # compute hash for this document to create unique index path
    dok_hash = _content_hash("\n".join(chunks))
    persist_dir = os.path.join(persist_root, dok_hash)
    os.makedirs(persist_dir, exist_ok=True)

    # get embedding client
    emb = get_embedding_model()

    # use Chroma to load or create a collection at persist_dir
    try:
        vs = Chroma(persist_directory=persist_dir, embedding_function=emb)
        # if empty or missing, (re)create from texts
        try:
            count = getattr(vs, "_collection").count()  # internal check; may vary by version
        except Exception:
            count = 0
        if count == 0:
            vs = Chroma.from_texts(chunks, emb, persist_directory=persist_dir)
            vs.persist()
    except Exception:
        # fallback: build fresh index
        vs = Chroma.from_texts(chunks, emb, persist_directory=persist_dir)
        vs.persist()

    # build retriever and retrieval qa chain
    retriever = vs.as_retriever(search_kwargs={"k": settings.TOP_K})
    qa = RetrievalQA.from_chain_type(llm=get_llm(), retriever=retriever, return_source_documents=True)
    return qa
