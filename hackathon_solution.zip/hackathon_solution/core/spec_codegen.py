# core/spec_codegen.py
# Spec extraction (RAG-backed) and code generation using LLM.
# Keep model temperature=0 for deterministic outputs.

import json
from typing import Dict, Any
from .rag_utils import build_rag_chain_from_text
from .llm_utils import get_llm

def extract_spec_json_from_text(text: str) -> Dict[str, Any]:
    """Use RAG chain to extract spec as normalized JSON.
    - text: full document text
    - returns parsed JSON (or error structure)
    """
    # build RAG chain from the whole text so the model can cite context
    qa = build_rag_chain_from_text(text)
    # question instructs the model to return a structured JSON spec
    question = "Convert the document into a JSON with a top-level 'services' list. Return JSON only."
    result = qa.invoke(question)  # uses retriever + llm under the hood
    raw = result.get("result", "") if isinstance(result, dict) else str(result)
    try:
        parsed = json.loads(raw)
    except Exception:
        parsed = {"error":"invalid_json","raw":raw}
    return parsed

def generate_code_files_from_spec(spec_json: Dict[str, Any]) -> Dict[str, str]:
    """Ask LLM to output code files (service.py, tests.py) as JSON mapping filename->contents.
    """
    llm = get_llm()
    prompt = f"Given this spec JSON, produce a JSON object mapping filenames to source code strings (service.py, tests.py). Spec: {json.dumps(spec_json)}"
    resp = llm.chat([{"role":"system","content":"Return valid JSON only."},{"role":"user","content":prompt}])
    # langchain_openai ChatOpenAI wrapper may expose results differently;
    # above call is illustrative — adapt to exact SDK response shape.
    raw = resp  # placeholder: adapt according to client implementation
    # If the client returns a dict, parse accordingly. For safety, wrap below:
    try:
        files = json.loads(raw if isinstance(raw, str) else raw.get("content",""))
    except Exception:
        files = {"error":"invalid_json","raw":str(raw)}
    return files
