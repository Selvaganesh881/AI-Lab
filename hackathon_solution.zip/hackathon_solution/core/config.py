# core/config.py
# Central configuration loaded from environment variables.
# Use this module throughout the app to avoid hard-coding values.

from __future__ import annotations
import os
from pydantic import BaseSettings, Field

# Pydantic BaseSettings reads env vars automatically; convenient for validation.
class Settings(BaseSettings):
    OPENAI_API_KEY: str = Field(..., env="OPENAI_API_KEY")
    BASE_URL: str = Field(..., env="BASE_URL")
    LLM_MODEL: str = Field("azure/genailab-maas-gpt-4o", env="LLM_MODEL")
    EMBEDDING_MODEL: str = Field("azure/genailab-maas-text-embedding-3-large", env="EMBEDDING_MODEL")
    WHISPER_MODEL: str = Field("azure/genailab-maas-whisper", env="WHISPER_MODEL")

    PERSIST_ROOT: str = Field("./indexes", env="PERSIST_ROOT")
    CHUNK_SIZE: int = Field(1000, env="CHUNK_SIZE")
    CHUNK_OVERLAP: int = Field(200, env="CHUNK_OVERLAP")
    TOP_K: int = Field(5, env="TOP_K")

    VERIFY_SSL: bool = Field(False, env="VERIFY_SSL")
    REQUEST_TIMEOUT_SECONDS: int = Field(60, env="REQUEST_TIMEOUT_SECONDS")

    class Config:
        env_file = ".env"     # load from .env in project root
        case_sensitive = False

# instantiate settings once and import settings where needed
settings = Settings()
