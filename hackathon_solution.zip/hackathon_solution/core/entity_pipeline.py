# core/entity_pipeline.py
# Entity extraction pipeline using local OCR (Tesseract) + LLM for structure and normalization.

import json
import re
from typing import Dict, Any, List
from .ocr_utils import ocr_image_bytes
import openai  # replace with your SDK client if needed

def extract_entities_from_text_block(text_block: str, model: str | None = None) -> Dict[str, Any]:
    """Ask the LLM to extract entities from a text block and return JSON.
    We request normalized dates/currencies and include confidence.
    """
    if model is None:
        model = "azure/genailab-maas-gpt-4o"  # default; swap via config if needed

    prompt = f"""Extract named entities from the text below. Return a JSON with key 'entities' that is an array of objects:
{{'type','value','context','confidence'}}. Normalize dates to YYYY-MM-DD and currency to {{currency, amount}} when possible.
Text:
{text_block}
Return ONLY valid JSON.
"""

    resp = openai.ChatCompletion.create(model=model, messages=[{"role":"system","content":"Return valid JSON only."},{"role":"user","content":prompt}], temperature=0)
    raw = resp.choices[0].message["content"]
    try:
        parsed = json.loads(raw)
    except Exception as e:
        parsed = {"error":"invalid_json","raw":raw,"parse_error":str(e)}
    return parsed

def normalize_entity_values(entity: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize dates and currencies in an entity; return entity with 'normalized' field.
    """
    value = entity.get("value","")
    etype = entity.get("type","").lower()
    normalized = value
    # date (simple matching)
    m = re.search(r"(\\d{4}-\\d{2}-\\d{2})", value)
    if m:
        normalized = m.group(1)
    else:
        m2 = re.search(r"(\\d{2})/(\\d{2})/(\\d{4})", value)
        if m2:
            d, mo, y = m2.groups()
            normalized = f"{y}-{mo}-{d}"
    # currency
    m3 = re.search(r"([\\$£€]|USD|INR|EUR)\\s*([\\d,]+\\.?\\d*)", value, re.I)
    if m3:
        cur, amt = m3.groups()
        normalized = {"currency": cur, "amount": float(amt.replace(",",""))}
    entity["normalized"] = normalized
    # ensure confidence
    entity.setdefault("confidence", 0.75)
    return entity
