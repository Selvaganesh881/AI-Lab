# core/pdf_utils.py
# Safe PDF ingestion & extraction using pdfminer.

import tempfile
import os
import io
from pdfminer.high_level import extract_text

def extract_pdf_text_bytes(file_bytes: bytes) -> str:
    """Extract text from PDF bytes.
    - write to temp file because pdfminer expects file-like or path
    - return the combined text of the PDF
    """
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        # write raw bytes to temp file for pdfminer
        tmp.write(file_bytes)
        tmp_path = tmp.name

    try:
        # extract_text reads and returns concatenated PDF text
        text = extract_text(tmp_path)
    finally:
        # cleanup temp file to avoid leaks
        try:
            os.unlink(tmp_path)
        except Exception:
            pass
    return text

def extract_pdf_text_file(file_path: str) -> str:
    """Convenience: extract text from a PDF on disk.
    """
    return extract_text(file_path)
