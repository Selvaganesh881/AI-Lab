# core/testcase_pipeline.py
# Generate test cases from user stories and verify traceability with a verifier model.

import json
from typing import Dict, Any, List
import openai  # replace as needed

def generate_test_cases_from_story(story_text: str, model: str | None = None) -> Dict[str, Any]:
    """Use LLM to generate 3-6 structured test cases for a user story.
    Returns JSON with keys 'story_id' and 'test_cases'.
    """
    if model is None:
        model = "azure/genailab-maas-gpt-4o"
    prompt = f"""User story:
{story_text}

Task: produce 3-6 test cases in JSON with fields: id, title, gherkin (Given/When/Then), priority, test_data, expected_result.
Return only valid JSON.
"""
    resp = openai.ChatCompletion.create(model=model, messages=[{"role":"system","content":"Return valid JSON only."},{"role":"user","content":prompt}], temperature=0)
    raw = resp.choices[0].message["content"]
    try:
        parsed = json.loads(raw)
    except Exception:
        parsed = {"error":"invalid_json","raw":raw}
    return parsed

def verify_test_case_against_spec(test_case: Dict[str, Any], spec_text: str, verifier_model: str | None = None) -> Dict[str, Any]:
    """Verify a generated test case maps to spec clauses, label mapping as Exact/Partial/Missing.
    Returns a JSON mapping for traceability.
    """
    if verifier_model is None:
        verifier_model = "azure_ai/genailab-maas-Phi-4-reasoning"
    prompt = f"""Spec:
{spec_text}

Test case:
{json.dumps(test_case)}

Task: list spec clauses this test covers and label each mapping as Exact/Partial/Missing with short justification. Return JSON only.
"""
    resp = openai.ChatCompletion.create(model=verifier_model, messages=[{"role":"system","content":"Return valid JSON only."},{"role":"user","content":prompt}], temperature=0)
    raw = resp.choices[0].message["content"]
    try:
        parsed = json.loads(raw)
    except Exception:
        parsed = {"error":"invalid_json","raw":raw}
    return parsed
