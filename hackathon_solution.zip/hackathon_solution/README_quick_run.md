# Quick Run (Local, no Docker)

## Prereqs (local machine)
1. Python 3.10+ installed.
2. Install Tesseract OCR:
   - Ubuntu: `sudo apt update && sudo apt install -y tesseract-ocr`
   - macOS (Homebrew): `brew install tesseract`
   - Windows: Install from https://github.com/tesseract-ocr/tesseract/releases and add to PATH.
3. Create Python venv and install dependencies:
   ```bash
   python -m venv .venv
   source .venv/bin/activate         # Windows: .venv\\Scripts\\activate
   pip install -r requirements.txt
   ```
4. Copy `.env.example` to `.env` and set your API keys and BASE_URL.

## Run Streamlit UI
```bash
streamlit run app_streamlit.py
```

## Run Gradio UI
```bash
python app_gradio.py
```

## Notes
- The app runs locally and persists vector indexes under `./indexes/` by default.
- Make sure Tesseract is installed and working; test with:
  ```python
  import pytesseract
  from PIL import Image
  print(pytesseract.image_to_string(Image.open("sample.png")))
  ```
