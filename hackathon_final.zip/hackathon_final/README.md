# Hackathon Final — Local Enterprise-Grade Package

## Overview
This package contains 5 problem folders (one per problem statement) plus shared utilities and sample data.
All code is designed to run locally (no Docker). Tesseract OCR must be installed on your machine.

## Quick start
1. Create virtualenv and install requirements:
   python -m venv .venv
   source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
   pip install -r requirements.txt
2. Copy `.env.example` to `.env` and set OPENAI_API_KEY and BASE_URL if using Azure GenAI.
3. Run any demo, e.g.:
   streamlit run problem_1_pdf_chatbot/run_pdf_chat.py
