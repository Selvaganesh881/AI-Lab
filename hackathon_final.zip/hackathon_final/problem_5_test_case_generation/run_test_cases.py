# problem_5_test_case_generation/run_test_cases.py
import streamlit as st, json, os
import openai
st.title('Problem 5 — Test Case Generation & Traceability')
story = st.text_area('Paste user story/spec', height=300)
if st.button('Generate Test Cases') and story.strip():
    prompt = f'Generate 3-6 structured test cases in JSON for this story: {story} Return only JSON.'
    try:
        resp = openai.ChatCompletion.create(model=os.getenv('LLM_MODEL','azure/genailab-maas-gpt-4o'), messages=[{'role':'system','content':'Return JSON only.'},{'role':'user','content':prompt}], temperature=0)
        gen = json.loads(resp.choices[0].message['content'])
    except Exception as e:
        gen = {'error':'generation_failed','detail':str(e)}
    st.subheader('Generated Test Cases'); st.json(gen)
    if isinstance(gen, dict) and gen.get('test_cases'):
        tc = gen['test_cases'][0]
        prompt2 = f"Given spec: {story}\nTest case: {json.dumps(tc)}\nMap this test to spec clauses and label Exact/Partial/Missing. Return JSON."
        try:
            resp2 = openai.ChatCompletion.create(model=os.getenv('VERIFIER_MODEL','azure_ai/genailab-maas-Phi-4-reasoning'), messages=[{'role':'system','content':'Return JSON only.'},{'role':'user','content':prompt2}], temperature=0)
            verify = json.loads(resp2.choices[0].message['content'])
        except Exception as e:
            verify = {'error':'verify_failed','detail':str(e)}
        st.subheader('Verification for first test case'); st.json(verify)
