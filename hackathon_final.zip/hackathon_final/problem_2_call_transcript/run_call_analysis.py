# problem_2_call_transcript/run_call_analysis.py
import streamlit as st, io, re, os, json
import openai  # placeholder - ensure you have credentials
st.title('Problem 2 — Call Transcript Analysis (Local)')
audio = st.file_uploader('Upload call audio (wav/mp3)', type=['wav','mp3','m4a'])
if audio and st.button('Transcribe & Analyze'):
    audio_bytes = audio.read()
    # transcription (placeholder - adapt to your SDK)
    try:
        resp = openai.Audio.transcriptions.create(model=os.getenv('WHISPER_MODEL','azure/genailab-maas-whisper'), file=io.BytesIO(audio_bytes))
        transcript = getattr(resp,'text', resp.get('text',''))
    except Exception as e:
        transcript = f'(transcription failed: {e})'
    # redact simple PII
    transcript = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}", '[REDACTED_EMAIL]', transcript)
    transcript = re.sub(r"\\b\\d{10}\\b", '[REDACTED_PHONE]', transcript)
    st.subheader('Transcript'); st.text_area('transcript', transcript, height=200)
    # analysis prompt
    prompt = f"""Transcript:\n{transcript}\n\nReturn JSON with keys: summary, sentiment{{label,confidence,reason}}, agent_eval{{greeting,empathy,policy_adherence,resolution,escalation_need,improvements}}"""
    try:
        analysis = openai.ChatCompletion.create(model=os.getenv('LLM_MODEL','azure/genailab-maas-gpt-4o'), messages=[{'role':'system','content':'Return JSON only.'},{'role':'user','content':prompt}], temperature=0)
        analysis_json = json.loads(analysis.choices[0].message['content'])
    except Exception as e:
        analysis_json = {'error':'analysis_failed','detail':str(e)}
    st.subheader('Analysis (JSON)'); st.json(analysis_json)
