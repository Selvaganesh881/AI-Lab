# problem_1_pdf_chatbot/run_pdf_chat.py
import streamlit as st, os, tempfile, hashlib
from shared.rag_utils import build_rag_chain_from_text
from pdfminer.high_level import extract_text

st.title('Problem 1 — PDF Chatbot (Local)')

uploaded = st.file_uploader('Upload PDF (<25 pages)', type=['pdf'])
if uploaded and st.button('Index PDF'):
    # save temp file and extract text
    with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp:
        tmp.write(uploaded.read()); tmp_path = tmp.name
    try:
        text = extract_text(tmp_path)
    finally:
        try: os.unlink(tmp_path)
        except: pass
    st.session_state['qa_chain'] = build_rag_chain_from_text(text)
    st.success('Indexed document. Ask questions now.')

if 'qa_chain' in st.session_state:
    q = st.text_input('Question about PDF:')
    if q and st.button('Ask'):
        res = st.session_state['qa_chain'].invoke(q)
        st.write(res.get('result','(no answer)'))
        srcs = res.get('source_documents', [])
        if srcs:
            with st.expander('Sources'):
                for i,d in enumerate(srcs, start=1):
                    st.write(d.page_content[:400].replace('\n',' '))
