# problem_4_entity_extraction/run_entity_extraction.py
import streamlit as st, json, os
from shared.ocr_utils import ocr_image_bytes
import openai
st.title('Problem 4 — Entity Extraction (Local)')
uploaded = st.file_uploader('Upload image (png/jpg) or PDF page saved as image', type=['png','jpg','jpeg','pdf'])
if uploaded and st.button('Extract Entities'):
    data = uploaded.read()
    # if pdf, user should supply a PDF page converted to image; for demo we treat all as image bytes
    ocr_text = ocr_image_bytes(data)
    st.subheader('OCR Text'); st.text_area('ocr', ocr_text, height=250)
    prompt = f"Extract entities from text below and return JSON with >=20 entities: {ocr_text}"
    try:
        resp = openai.ChatCompletion.create(model=os.getenv('LLM_MODEL','azure/genailab-maas-gpt-4o'), messages=[{'role':'system','content':'Return JSON only.'},{'role':'user','content':prompt}], temperature=0)
        parsed = json.loads(resp.choices[0].message['content'])
    except Exception as e:
        parsed = {'error':'llm_failed','detail':str(e)}
    st.subheader('Entities'); st.json(parsed)
