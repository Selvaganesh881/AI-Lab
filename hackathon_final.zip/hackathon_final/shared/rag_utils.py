# shared/rag_utils.py
import os, hashlib
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain.chains import RetrievalQA
from .llm_utils import get_llm, get_embedding_model
from .config import settings

def _content_hash(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()[:16]

def build_rag_chain_from_text(text: str, persist_root: str | None = None):
    if persist_root is None:
        persist_root = settings.PERSIST_ROOT
    os.makedirs(persist_root, exist_ok=True)
    splitter = RecursiveCharacterTextSplitter(chunk_size=settings.CHUNK_SIZE, chunk_overlap=settings.CHUNK_OVERLAP)
    chunks = splitter.split_text(text)
    doc_hash = _content_hash('\n'.join(chunks))
    persist_dir = os.path.join(persist_root, doc_hash)
    os.makedirs(persist_dir, exist_ok=True)
    emb = get_embedding_model()
    try:
        vs = Chroma(persist_directory=persist_dir, embedding_function=emb)
        try:
            count = getattr(vs, '_collection').count()
        except Exception:
            count = 0
        if count == 0:
            vs = Chroma.from_texts(chunks, emb, persist_directory=persist_dir)
            vs.persist()
    except Exception:
        vs = Chroma.from_texts(chunks, emb, persist_directory=persist_dir)
        vs.persist()
    retriever = vs.as_retriever(search_kwargs={'k': settings.TOP_K})
    qa = RetrievalQA.from_chain_type(llm=get_llm(), retriever=retriever, return_source_documents=True)
    return qa
