# shared/ocr_utils.py
# Local Tesseract OCR helpers
import io
from PIL import Image
import pytesseract

def ocr_image_bytes(image_bytes: bytes, lang: str = 'eng') -> str:
    image = Image.open(io.BytesIO(image_bytes))
    text = pytesseract.image_to_string(image, lang=lang)
    return text
