# shared/nlp_utils.py
# Small helper functions (local) for summarization/sentiment using an LLM client directly if needed.
import json
import openai

def ask_llm_json(prompt: str, model: str):
    resp = openai.ChatCompletion.create(model=model, messages=[{'role':'system','content':'Return JSON only.'},{'role':'user','content':prompt}], temperature=0)
    raw = resp.choices[0].message['content']
    try:
        return json.loads(raw)
    except Exception:
        return {'error':'invalid_json','raw':raw}
