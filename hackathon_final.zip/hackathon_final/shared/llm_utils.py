# shared/llm_utils.py
# Lightweight wrappers to create LangChain OpenAI/Azure clients.
from __future__ import annotations
import httpx
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from .config import settings

_http_client: httpx.Client | None = None

def get_http_client() -> httpx.Client:
    global _http_client
    if _http_client is None:
        _http_client = httpx.Client(verify=settings.VERIFY_SSL, timeout=settings.REQUEST_TIMEOUT_SECONDS)
    return _http_client

def get_llm():
    return ChatOpenAI(
        base_url=settings.BASE_URL,
        model=settings.LLM_MODEL,
        api_key=settings.OPENAI_API_KEY,
        http_client=get_http_client(),
        timeout=settings.REQUEST_TIMEOUT_SECONDS,
        temperature=0.0,
    )

def get_embedding_model():
    return OpenAIEmbeddings(
        base_url=settings.BASE_URL,
        model=settings.EMBEDDING_MODEL,
        api_key=settings.OPENAI_API_KEY,
        http_client=get_http_client(),
    )
