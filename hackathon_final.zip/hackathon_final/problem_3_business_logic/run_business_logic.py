# problem_3_business_logic/run_business_logic.py
import streamlit as st, json, os
from shared.rag_utils import build_rag_chain_from_text
import openai
st.title('Problem 3 — Business Logic Automation (Local)')
spec = st.text_area('Paste spec text', height=300)
if st.button('Extract Spec & Generate Code') and spec.strip():
    qa = build_rag_chain_from_text(spec)
    q = 'Convert the document into structured JSON with services, inputs, outputs, and rules. Return JSON only.'
    res = qa.invoke(q)
    raw = res.get('result','') if isinstance(res, dict) else str(res)
    try:
        spec_json = json.loads(raw)
    except Exception:
        spec_json = {'error':'invalid_json','raw':raw}
    st.subheader('Spec JSON'); st.json(spec_json)
    prompt = f'Generate service.py and tests.py in a JSON mapping for spec: {json.dumps(spec_json)}'
    try:
        g = openai.ChatCompletion.create(model=os.getenv('LLM_MODEL','azure/genailab-maas-gpt-4o'), messages=[{'role':'system','content':'Return JSON only.'},{'role':'user','content':prompt}], temperature=0)
        files = json.loads(g.choices[0].message['content'])
    except Exception as e:
        files = {'error':'codegen_failed','detail':str(e)}
    st.subheader('Generated Files'); st.json(files)
